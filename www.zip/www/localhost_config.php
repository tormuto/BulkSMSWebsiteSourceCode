<?php
define('_DB_HOST_','localhost');
define('_CURRENCY_CODE_','NGN');
define('_DB_NAME_','project_cgsms2');
define('_DB_PREFIX_','');
define('_DB_USERNAME_','root');
define('_DB_PASS_',"root");
define('_ADMIN_EMAIL_','tormuto@gmail.com');
define('_ADMIN_PASS_',"omodaadaa");

define('_BASE_URL_','http://localhost/bestsmsgateway.com/');
define('_DEFAULT_MAIL_SENDER_','Best SMS Gateway');

define('_SMTP_HOST_','mail.localhost');
define('_SMTP_USER_','no_reply@localhost');
define('_SMTP_PASS_','omodaadaa');
define('_SMTP_PORT_','587');
?>