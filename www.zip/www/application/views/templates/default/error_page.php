<div class='alert alert-danger'>
	<span class='close' data-dismiss='alert'>&times;</span>
	<?php echo $msg;?>
</div>